﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// ColorImageAlpha1.rc에서 사용되고 있습니다.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_ColorImageAlpha1TYPE        130
#define IDD_CONSTANT                    312
#define IDD_CONSTANT1                   314
#define IDD_CONSTANT3                   320
#define IDD_CONSTANT2                   322
#define IDCANCEL                        1001
#define IDC_EDIT_CONSTANT               1002
#define IDC_CONSTANT_TWIST              1006
#define IDC_CONSTANT2                   1007
#define ID_32771                        32771
#define IDM_EQUAL_IMAGE                 32772
#define ID_32773                        32773
#define IDM_GRAYSCALE_IMAGE             32774
#define ID_32775                        32775
#define IDM_ADD_IMAGE                   32776
#define ID_32777                        32777
#define ID_32778                        32778
#define ID_32779                        32779
#define IDC_BW_IMAGE                    32780
#define IDC_AVGBW_IMAGE                 32781
#define ID_32782                        32782
#define ID_32783                        32783
#define ID_32784                        32784
#define ID_32785                        32785
#define ID_32786                        32786
#define ID_32787                        32787
#define IDC_REV_IMAGE                   32788
#define IDC_BRPARA_IMAGE                32789
#define IDC_DAPARA_IMAGE                32790
#define IDC_GAMMA_IMAGE                 32791
#define IDC_MIRROR_IMAGE                32792
#define ID_32793                        32793
#define IDM_                            32794
#define IDM_CHANGE                      32795
#define IDM_CHANGE_SATUR                32796
#define ID_32797                        32797
#define IDM_PICK_ORANGE                 32798
#define ID_32799                        32799
#define ID_32800                        32800
#define ID_32801                        32801
#define ID_32802                        32802
#define ID_32803                        32803
#define ID_32804                        32804
#define ID_32805                        32805
#define ID_32806                        32806
#define IDM_ROTATE_IMAGE                32807
#define ID_BASIC_IMAGE                  32808
#define IDM_MID_ZOOMOUT                 32809
#define IDM_AVG_ZOOMOUT                 32810
#define IDM_ZOOMOUT                     32811
#define IDM_BIL_ZOOMIN                  32812
#define IDM_ZOOMIN                      32813
#define ID_32814                        32814
#define ID_32815                        32815
#define IDM_EMBOSS                      32816
#define ID_32817                        32817
#define IDM_EMBOSS_HSI                  32818
#define ID_32819                        32819
#define ID_32820                        32820
#define ID_32821                        32821
#define ID_32822                        32822
#define IDM_STRECH_IMAGE                32823
#define IDM_HISEQ_IMAGE                 32824
#define IDM_ENDIN_IMAGE                 32825
#define ID_32826                        32826
#define ID_32827                        32827
#define ID_32828                        32828
#define IDM_BLUR_IMAGE                  32829
#define IDM_SHARP_IMAGE                 32830
#define ID_32831                        32831
#define ID_32832                        32832
#define IDM_VEREDGE_IMAGE               32833
#define IDM_PAL_IMAGE                   32834
#define ID_32835                        32835
#define IDM_TWIST_IMAGE                 32836

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        324
#define _APS_NEXT_COMMAND_VALUE         32837
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
